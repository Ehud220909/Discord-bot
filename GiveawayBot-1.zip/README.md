
**This Giveaway bot was created by GhostGenix#8658**

**IN CONFIG.JSON DO NOT CHANGE ANY VARIABLE THE everyoneMention VARIABLE IS FOR THE EVERYONE MENTION WHEN A NEW GIVEAWAY OCCURS AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES 
INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!**
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/channel/UCRDxYBCF60gsgxb0u9Z49_Q)
- 🔗 [Support Server Link](https://discord.gg/HAsJKecZCa)
# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give me credits for the same. Thanks



